
package com.mycompany.aulas;

public class Horista extends Funcionario{
    
    // Atributos
    private Integer qtdHoras;            // quantidade de horas trabalhadas no mês
    private Double valorHora;           // valor ganho por hora trabalhada
    
    // Construtor
    public Horista(String cpf, String nome, Integer qtdHoras, Double valorHora) {
        super(cpf, nome);
        this.qtdHoras = qtdHoras;
        this.valorHora = valorHora;
    }
    
    // Métodos

    // Implementação do método abstrato calcSalario()
    @Override
    public Double calcSalario() {
        return qtdHoras * valorHora;
    }
    
    // toString()
    @Override
    public String toString() {
        return "Horista{" + super.toString() + ", qtdHoras=" + qtdHoras + 
                ", valorHora=" + valorHora + ", salário=" + calcSalario() + '}';
    }
    
    // Getters

    public Integer getQtdHoras() {
        return qtdHoras;
    }

    public Double getValorHora() {
        return valorHora;
    }
    
    

}
