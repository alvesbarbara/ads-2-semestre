package com.mycompany.aulas;

import java.util.ArrayList;
import java.util.List;


public class Empresa {
    
    // Atributos
    private String nome;                // nome da empresa
    private List<Funcionario> lista;    // lista de funcionários da empresa
    
    // Construtor
    public Empresa (String nome) {
        this.nome = nome;
        lista = new ArrayList<Funcionario>(); 
    }
    
    // Métodos
    
    // Método adicionaFunc - recebe um objeto Funcionario e adiciona-o à lista
    public void adicionaFunc(Funcionario f) {
        lista.add(f);
    }
    
    // Método exibeTodos - exibe todos os objetos da lista de funcionários
    public void exibeTodos() {
        System.out.println("\nLista dos funcionários:");
        for (Funcionario f : lista) {
            System.out.println(f);
        }
    }

    // Método exibeVendedores - exibe todos os objetos vendedores da lista de funcionários
    public void exibeVendedores() {
        System.out.println("\nLista dos vendedores:");
        for (Funcionario f : lista) {
            if (f instanceof Vendedor) {
                System.out.println(f);
            }
        }
    }
    
    // Método exibeTotalSalario - calcula e retorna o total gasto em salário nesse mês
    public void exibeTotalSalario() {
        Double total = 0.0;
        for (Funcionario f : lista) {
            total += f.calcSalario();
        }
        System.out.println("\nTotal de salários gasto: " + total);
    } 
    
}
        
    
   
   

