
package com.mycompany.aulas;

public class Vendedor extends Funcionario {
    
    // Atributos
    private Double vendas;      // Quantia de vendas realizadas no mês
    private Double taxa;        // Taxa de comissão ganho sobre as vendas
    
    // Construtor
    public Vendedor(String cpf, String nome, Double vendas, Double taxa) {
        super(cpf, nome);
        this.vendas = vendas;
        this.taxa = taxa;
    }
    
    // Métodos
    
    // Implementação do método abstrato calcSalario()
    @Override
    public Double calcSalario() {
        return vendas * taxa;
    }
    
    // toString()
    @Override
    public String toString() {
        return "Vendedor{" + super.toString() + ", vendas=" + vendas +
                ", taxa=" + taxa + ", salário=" + calcSalario() + '}';
    }
    
    // Getters

    public Double getVendas() {
        return vendas;
    }

    public Double getTaxa() {
        return taxa;
    }
    
    
}
