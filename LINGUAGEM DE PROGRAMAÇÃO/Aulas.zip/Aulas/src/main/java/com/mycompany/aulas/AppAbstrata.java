
package com.mycompany.aulas;


public class AppAbstrata {
    public static void main(String[] args) {
        
        // Cria um objeto vendedor e um horista
        Horista v = new Horista("50000", "Claudio", 50, 20000.0);
        Horista h = new Horista("60000", "Horácio", 40, 100.0);
        
        // Exibe os dados dos objetos criados
        System.out.println(v);
        System.out.println(h);
        
        // Cria objeto Empresa
        Empresa bandtec = new Empresa("Bandtec");

        // Adiciona os objetos v e h á lista de funcionários da empresa bandtec
        bandtec.adicionaFunc(v);
        bandtec.adicionaFunc(h);
        
        // Exibe todos os funcionários
        bandtec.exibeTodos();
        
        // Exibe apenas os vendedores
        bandtec.exibeVendedores();
        
        // Exibe o total gasto em salário
        bandtec.exibeTotalSalario();
        
    }
    
}