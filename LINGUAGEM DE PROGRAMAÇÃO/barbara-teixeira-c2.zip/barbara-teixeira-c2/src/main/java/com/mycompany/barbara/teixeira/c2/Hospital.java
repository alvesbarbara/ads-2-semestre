
package com.mycompany.barbara.teixeira.c2;

public class Hospital {
   //Atributos 
   private String nome;
   private Integer quantidadeLeitos = 0;
   private Integer listaDePacientes = 0;
   
public String getNome(){
return nome;
}

public void setNome(String nome){
this.nome = nome;
}


public Integer getLeitos(){
return quantidadeLeitos;
}

public void setLeitos (Integer quantidadeLeitos){
this.quantidadeLeitos = quantidadeLeitos;
}

public Integer getPacientes(){
return listaDePacientes;
}

public void setPacientes (Integer listaDePacientes){
this.listaDePacientes = listaDePacientes;
}

public void internarPaciente(){
while(this.quantidadeLeitos > 20){
    System.out.println("Paciente internado!");
    this.quantidadeLeitos++;
}
}
    


}

//d ) A classe Hospital deverá conter os seguintes atributos:
//    nome
//    quantidadeLeitos
//    listaDePacientes
//e ) A classe Hospital deverá conter um método chamado internarPaciente,
//que verifica se há leitos e caso possua, interna o paciente e diminui o número de leitos em 1,
//caso contrário, exibe a seguinte mensagem: “não foi possível internar o paciente NOME,
//será necessário transferi-lo”, onde NOME deverá ser substituido pelo nome do paciente recebido.
//f ) A classe Hospitaldeverá ter um método chamado exibeDadosPacientes() 
//que verifica se há pacientes internados, caso possua, exibe de maneira organizada 
//os dados de todos os pacientes, caso contrário, exibe a seguinte mensagem: “Não há pacientes internados.”
//g ) A classe Hospital deverá conter um método chamado exibeLeitos() 
//que imprime no console a seguinte mensagem "Quantidade de leitos disponíveis:
//QUANTIDADE" onde QUANTIDADE é o número atual de leitos disponíveis.
