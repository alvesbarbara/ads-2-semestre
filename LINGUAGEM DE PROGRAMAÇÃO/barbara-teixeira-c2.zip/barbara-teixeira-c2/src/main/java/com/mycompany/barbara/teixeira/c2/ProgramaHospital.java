
package com.mycompany.barbara.teixeira.c2;

public class ProgramaHospital {
    
    public static void main(String[] args) {
       
        Hospital pac = new Hospital();
 
    }    
}



//h ) A classe ProgramaHospital deverá criar objetos do tipo Paciente com diferentes valores.
//
//i )A classe ProgramaHospital deverá criar um objeto do tipo Hospital.
//
//j ) Interne alguns pacientes no hospital criado e teste os diferentes cenários.
