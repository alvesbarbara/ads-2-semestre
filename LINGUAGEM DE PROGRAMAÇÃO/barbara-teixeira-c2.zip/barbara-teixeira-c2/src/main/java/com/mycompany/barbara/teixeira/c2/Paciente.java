
package com.mycompany.barbara.teixeira.c2;

public class Paciente {
    private String nome = "";
    private Integer idade = 0;
    private String planoDeSaude = "";
    

    
public void exibeDados(){
System.out.println(String.format
        ("Dados do paciente", this.nome, this.idade, this.planoDeSaude, "\n"));
}

public String getNome(){
return nome;
}

public void setNome(String nome){
this.nome = nome;
}

public Integer geIdade(){
return idade;
}

public void setNome(Integer idade){
this.idade = idade;
}


public String getPlano(){
return planoDeSaude;
}

public void setPlano(String nome){
this.planoDeSaude = planoDeSaude;
}

}

//    A classe Paciente deverá conter os seguintes atributos:
//    nome
//    idade
//    planoDeSaude
//    A classe Paciente deverá conter um método chamado exibeDados(),
//    que imprime de maneira organizada no console os dados do paciente.