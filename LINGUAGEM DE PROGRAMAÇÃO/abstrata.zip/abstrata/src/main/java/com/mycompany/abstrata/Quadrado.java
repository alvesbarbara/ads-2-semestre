
package com.mycompany.abstrata;


public class Quadrado extends Figura {
    protected Double lado;

    public Quadrado(String cor, Integer espessura, Double lado) {
        super (cor, espessura);
        this.lado = lado;
    }

    @Override
    public Double calculaArea() {
        return lado * lado;
        
        
    }

    @Override
    public String toString() {
        return super.toString();
    }
  
    
}


