package com.mycompany.abstrata;

import java.util.ArrayList;
import static java.util.Collections.list;
import java.util.List;

public class Imagem {
protected String nome;
protected List<Figura> lista;

public Imagem(String nome ) {
        this.nome = nome;
        lista = new ArrayList<Figura>();// ??colocando figura aqui significa q depois pode ser declardo quadrado como na linha 42
    }
    
 public void addFigura(Figura f){
        lista.add(f);
        }  
  
public void exibeFiguras(){
    System.out.println("\n Figuras: ");
     for (Figura f : lista) {
            System.out.println(f);
        }
}
public void exibeSomaArea() {
        Double total = 0.0;
        for (Figura f : lista) {
            total += f.calculaArea();
        }
        System.out.println("\nSoma da aréa é: " + total);
}
public void exibeFiguraAreaMaior20() {
for(Figura f : lista) {
if(f.calculaArea() > 20) {
System.out.println("Figura: " + f);
}
 }
}

 public void addQuadrado(Quadrado q){
 lista.add(q);
 }

public void exibeQuadrado(){
    System.out.println("\n Cada um no seu quadrado: ");
     for (Figura q: lista) {
            System.out.println(q);
        }

}
}
        
