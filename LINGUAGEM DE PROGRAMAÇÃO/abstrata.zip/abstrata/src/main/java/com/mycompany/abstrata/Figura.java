
package com.mycompany.abstrata;

public abstract class Figura {
   protected String cor;
   protected Integer espessura;

    public Figura(String cor, Integer espessura) {
        this.cor = cor;
        this.espessura = espessura;
    }
   
   
   
public abstract Double calculaArea();

    @Override
    public String toString() {
        return "Figura" + "cor=" + cor + ", espessura=" + espessura + '}';
        
    }

    public String getCor() {
        return cor;
    }

    public Integer getEspessura() {
        return espessura;
    }

    public void setCor(String cor) {
        this.cor = cor;
    }

    public void setEspessura(Integer espessura) {
        this.espessura = espessura;
    }
   
}

