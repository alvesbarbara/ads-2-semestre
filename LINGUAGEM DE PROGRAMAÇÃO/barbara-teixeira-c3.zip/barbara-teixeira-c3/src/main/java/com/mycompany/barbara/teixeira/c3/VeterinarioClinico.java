package com.mycompany.barbara.teixeira.c3;

public class VeterinarioClinico {
    
protected Integer codigo, qtdConsulta;
protected String nome;
protected Double valorConsulta;
    


public VeterinarioClinico(Integer codigo, Integer qtdConsulta, String nome, Double valorConsulta){
this.codigo = codigo;
this.qtdConsulta = qtdConsulta;    
this.nome = nome;
this.valorConsulta = valorConsulta;

}
public Double calcularSalario(){
Double resultado = qtdConsulta * valorConsulta;
 return resultado; 
}

    public Integer getCodigo() {
        return codigo;
    }

    public Integer getQtdConsulta() {
        return qtdConsulta;
    }

    public String getNome() {
        return nome;
    }

    public Double getValorConsulta() {
        return valorConsulta;
    }
    

@Override
public String toString() {
    return "\nNome: " + this.nome + "\nCódigo: " + this.codigo + "\nsalário " + this.calcularSalario() ;
}

}
// Uma classe chamado "VeterinarioClinico", ela deve conter:
//    I. Atributos:
//        codigo - Integer - representa o código do veterinário(CRMV).
//        nome - String - representa o nome do veterinário.
//        qtdConsulta - Integer - representa o número de consultas realizadas.
//        valorConsulta - Double - representa o valor da consulta.
//    II. Métodos:
//        calcularSalario() - retorna um Double - esse método deve retornar a quantidade 
//de consultas realizadas vezes o valor da consulta.
//        toString() - retorna uma String - sobreescrita do método "toString" para informar
//os valores do objeto, inclusive o salário, mas não precisa criar o atributo salário.