
package com.mycompany.projeto.professor.heranca;

public class Cordenador extends Professor {
	
	protected Integer qtdHorasCoord;
	protected Double valorHoraCoord;
	protected String curso;
	
	
	public Cordenador(String nome, String curso, Integer codigo, Integer horas, Integer qtdHorasCoord, Double valorHoras, Double valorHoraCoord) {
        super(nome, codigo, horas, valorHoras);

        this.qtdHorasCoord = qtdHorasCoord;
        this.valorHoraCoord = valorHoraCoord;
        this.curso = curso;
    }
	
	@Override
	public Double calcularSalario() {
		Double ganhoCodMes = qtdHorasCoord * valorHoraCoord * 4.5;
		ganhoCodMes += qtdHorasCoord * valorHoraCoord * 4.5;
		return ganhoCodMes ;
	}
	
	@Override
	public Integer getCodigo() {
		
		return super.getCodigo();
	}
	@Override
	public Integer getHoras() {
		// TODO Auto-generated method stub
		return super.getHoras();
	}
	@Override
	public String getNome() {
		// TODO Auto-generated method stub
		return super.getNome();
	}
	@Override
	public Double getValorHora() {
		// TODO Auto-generated method stub
		return super.getValorHora();
	}
	public String getCurso() {
		return curso;
	}
	public Integer getQtdHorasCoord() {
		return qtdHorasCoord;
	}
	public Double getValorHoraCoord() {
		return valorHoraCoord;
	}
	
	@Override
	public String toString() {
		return "\nNome: " + this.nome + "\nCódigo: " + this.codigo + "\nHoras: " + this.qtdHorasCoord +
				"\nHoras P: " + this.horas + "\nValor Hora: " + this.valorHoraCoord + 
				"\nValor Hora P: " + this.valorHora + 
				"\nSálario do Coordenador: " + calcularSalario() ;
	}
}
    
 