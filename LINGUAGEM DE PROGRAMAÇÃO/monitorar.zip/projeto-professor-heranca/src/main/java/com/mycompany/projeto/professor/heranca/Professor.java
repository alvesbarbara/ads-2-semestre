package com.mycompany.projeto.professor.heranca;
/**
 *
 * @author re92260z
 */
public class Professor {
    protected String nome;
    protected Integer codigo ;
    protected Integer horas;
    protected Double valorHora;

    public Professor(String nome,Integer codigo,Integer horas,Double valorHora) {
        this.codigo = codigo;
        this.horas = horas;
        this.nome = nome;
        this.valorHora = valorHora;
    }

    public  Double calcularSalario() {
        Double salarioProfessor = horas * valorHora;
        return  salarioProfessor = salarioProfessor *4.5;
    }


    public Integer getCodigo() {
        return codigo;
    }
    public Integer getHoras() {
        return horas;
    }
    public String getNome() {
        return nome;
    }
    public Double getValorHora() {
        return valorHora;
    }

    @Override
    public String toString() {
        return "\nNome: " + this.nome + "\nCódigo: " + this.codigo + "\nHoras: " + this.horas + "\nValor Hora: " + this.valorHora + "\nSálario: " + calcularSalario() ;
    }

}

    
