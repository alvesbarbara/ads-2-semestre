package aula20_05_2020;

public class Triatleta extends Corredor {
    public Triatleta(String tipoFisico, String performace,Double tempoMedio){
    super(tipoFisico, performace, tempoMedio);
    }
    
}
