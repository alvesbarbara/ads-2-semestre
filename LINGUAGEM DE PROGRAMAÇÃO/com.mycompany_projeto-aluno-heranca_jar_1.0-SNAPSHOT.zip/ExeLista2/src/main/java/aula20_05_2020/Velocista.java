package aula20_05_2020;


public class Velocista extends Corredor {
    
  public Velocista(String tipoFisico, String performace, Double tempoMedio) {
        super(tipoFisico, performace, tempoMedio);
    }
    
}
