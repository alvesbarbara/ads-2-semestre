
package aula20_05_2020;

public class Maratonista extends Corredor {
    
    public Maratonista (String tipoFisico, String performace, Double tempoMedio) {
        super(tipoFisico, performace, tempoMedio);
    }
        

    }


