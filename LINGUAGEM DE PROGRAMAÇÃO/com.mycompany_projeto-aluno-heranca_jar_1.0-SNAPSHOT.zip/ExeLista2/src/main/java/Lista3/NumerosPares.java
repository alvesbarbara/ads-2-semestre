
package Lista3;

public class NumerosPares {
    public static void main(String[] args) {
        
        int i = 0;
        while(i <=40){
            if (i % 2 == 0){
                System.out.println(i);
         }
           i++;
    }   
    } 
    }
        
//        for (Integer i = 0; i <=40; i+=2) {
//            System.out.println(i);
//        }
        
        
  
