package com.mycompany.abstrata;

public class AppFigura {
    public static void main(String[] args) {
        
        Figura qd = new Quadrado("verde", 2,6.0);//cor epessura lado
        Figura rt = new Retangulo("preto", 6, 8.0, 10.0);//String cor, Integer espessura, Double base, Double altura
    
        System.out.println(qd);
        System.out.println(rt);
    
       
    }     
}
