
package com.mycompany.abstrata;

public class Retangulo extends Figura{
    protected Double base, altura;

    public Retangulo(String cor, Integer espessura, Double base, Double altura) {
        super(cor, espessura);
        this.base = base;
        this.altura = altura;
    }
    
    @Override
    public Double calculaArea() {
        return (base * altura)/ 2;
    }

    @Override //?tem como ser abstact em figura? ou não por já ser um override?
    public String toString() {
        return "Retangulo{" + "base=" + base + ", altura=" + altura + '}';
    }
    
    
}
