package com.mycompany.barbara.teixeira.c3;

public class VeterinarioCirurgiao extends VeterinarioClinico {
    
    protected Integer qtdCirurgia;
    protected Double valorCirurgia;

    public VeterinarioCirurgiao(Integer qtdCirurgia, Double valorCirurgia, Integer codigo, Integer qtdConsulta, String nome, Double valorConsulta) {
       
        super(codigo, qtdConsulta, nome, valorConsulta);
        
        this.qtdCirurgia = qtdCirurgia;
        this.valorCirurgia = valorCirurgia;
        
        
    }

    public Integer getQtdCirurgia() {
        return qtdCirurgia;
    }

    public Double getValorCirurgia() {
        return valorCirurgia;
    }
    

    
    @Override
    public Double calcularSalario(){
    Double resultado = (this.qtdConsulta * this.valorConsulta) + (this.qtdCirurgia * this.valorCirurgia);
    return resultado;

}

    @Override
    public String toString() {
        return String.format("Veterinario Cirurgiao "+ nome + " \nCirurgias Realizadas = " + qtdCirurgia 
                + "\nvalor da Cirurgia=" + valorCirurgia + "\nsalario: " + calcularSalario());
    }
    
    
    
    
    
    
}


//b) Uma classe chamada "VeterinarioCirurgiao", herdeira de "VeterinarioClinico", ela deve conter:
//
//    I. Atributos:
//
//        qtdCirurgia - Integer - representa a quantidade de cirurgias realizadas.
//
//        valorCirurgia - Double - representa o valor da cirurgia.
//
//    II. Métodos:
//
//        calcularSalario() - retorna um Double - esse método deve ser sobreescrito, o calculo anterior permanece, 
//porém devemos acrescentar os valores de cirurgia:
// qtdConsulta vezes valorConsulta mais qtdCirurgia vezes valorCirurgia.
//
//        toString() - retorna uma String - sobreescrita do método "toString" para informar os valores do objeto, inclusive o salário.