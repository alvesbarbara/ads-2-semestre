
package com.mycompany.barbara.teixeira.c3;


public class App {
    public static void main(String[] args) {
       VeterinarioClinico vetC1 = new VeterinarioClinico (1000, 10, "Diego", 250.0);
       VeterinarioClinico vetC2 = new VeterinarioClinico (1010, 20, "Pedro", 200.0);
       
       VeterinarioCirurgiao vet1 = new  VeterinarioCirurgiao (10, 300.0, 2000, 12, "Bruce Wane", 230.0);
       VeterinarioCirurgiao vet2 = new  VeterinarioCirurgiao (14, 340.0, 2010, 45, "Carlos Daniel", 500.0);
       
    
        System.out.println(vetC1);
        System.out.println(vetC2);
        System.out.println(vet1);
        System.out.println(vet2);
    
    
    
    
    
    
    }
      
    
}


//c) Uma classe chamada "App", ela deve ser executável e deverá:
//
//    I. Ter no minímo dois objetos do tipo "VeterinarioClinico".
//
//    II. Ter no minímo dois objetos do tipo "VeterinarioCirurgiao".
//
//    III. Invocar e apresentar os dados e salário de cada um deles.