
package com.mycompany.aulas;

import java.util.ArrayList;
import java.util.List;

public class ExemploLista {
    
    public static void main(String[] args) {
        
        // O conceito de List que vamos ver hoje é um conceito de lista dinâmica
        // Seu tamanho é alterado durante a execução do programa 
        
        // O conceito de vetor é um conceito de lista estática
        // Uma vez criado o vetor, seu tamanho não pode ser alterado durante
        // a execução do programa
        
        // List é uma interface (conjunto de definições de métodos)
        // Uma interface não é instanciável
        // ArrayList é uma das classes que implementam a interface List
        
        // Estamos criando uma listaLoka que aceita elementos de diversos tipos
        List listaLoka = new ArrayList<>();
        
        // Adicionando elementos à listaLoka
        listaLoka.add(50000);
        listaLoka.add("Boa noite!");
        listaLoka.add(79.99);
        listaLoka.add(false);
        
        // Exibe a listaLoka
        System.out.println("listaLoka: " + listaLoka);
        
        // Exibe o tamanho da listaLoka
        System.out.println("Tamanho da listaLoka: " + listaLoka.size());
        
        // Exibe elementos num determinado índice
        System.out.println("Elemento do índice 2: " + listaLoka.get(2));
        System.out.println("Elemento do índice 0: " + listaLoka.get(0));
        System.out.println("Elemento do índice 3: " + listaLoka.get(3));
        
        // isEmpty() retorna true se a lista está vazia
        System.out.println("listaLoka está vazia? " + listaLoka.isEmpty());
        
        if (listaLoka.isEmpty()) {
            System.out.println("Ta vazia.");
        }else{
            System.out.println("Não está vazia.");
        }

        // contains(elemento) retorna true se o elemento está na lista
        System.out.println("79.99 está na listaLoka? " + listaLoka.contains(79.99));
        
        // Remove elementos : método remove aceita o elemento ou o índice do elemento
        System.out.println("Removendo o elemento Boa noite!...");
        listaLoka.remove("Boa noite!");
        // Exibe a listaLoka
        System.out.println("listaLoka: " + listaLoka);
        // Exibe o tamanho da listaLoka
        System.out.println("Tamanho da listaLoka: " + listaLoka.size());
        
        System.out.println("Removendo o elemento do índice 1...");
        listaLoka.remove(1);
        // Exibe a listaLoka
        System.out.println("listaLoka: " + listaLoka);
        // Exibe o tamanho da listaLoka
        System.out.println("Tamanho da listaLoka: " + listaLoka.size());
        
        // Método clear() - limpa a lista
        System.out.println("Executando o método clear()...");
        listaLoka.clear();
        // Exibe a listaLoka
        System.out.println("listaLoka: " + listaLoka);
        // Exibe o tamanho da listaLoka
        System.out.println("Tamanho da listaLoka: " + listaLoka.size());
        
        
        
    }
    
}

    

