package com.mycompany.aulas;

public class ContaCorrenteApp {
    public static void main(String[] args) {
        ContaCorrente conta1 = new ContaCorrente();
        
          System.out.println("Depositando biroliros");
        conta1.depositar50();
        conta1.depositar50();
        conta1.depositar50();
        conta1.depositar50();
        
        System.out.println(String.format(" saldo atual é: %.2f",  conta1.saldo));
        
    
    
    }
    
}
