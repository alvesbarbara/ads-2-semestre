package com.mycompany.aulas;
// A forma de conta corrente está a seguir...
public class ContaCorrente {
   //atributos
    Double saldo = 0.0;
   
    //métodos/comportamentos
    void depositar50(){ //VOID INDICA QUE NÃO ESTÁ DANDO RETORNO
    saldo += 50;
}
    
    void sacar50(){
    saldo -= 50;
    }
    
}
