
package com.mycompany.exercicio.aluno;

import java.util.ArrayList;
import java.util.List;

public class Cadastro {
    
private List<Aluno> aluno;
    
public Cadastro(Double teste){
    
 this.aluno = new ArrayList();
}   

    public void addAluno(Aluno aluno){
    aluno.add(aluno);
    }
    
    public void exibeAlunosFundamental(){   
    if (!aluno.isEmpty()){
   
}
