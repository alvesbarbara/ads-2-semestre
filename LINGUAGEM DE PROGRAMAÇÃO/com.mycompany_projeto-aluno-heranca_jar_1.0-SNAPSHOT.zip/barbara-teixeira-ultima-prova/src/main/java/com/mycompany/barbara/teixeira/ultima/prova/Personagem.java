
package com.mycompany.barbara.teixeira.ultima.prova;

import java.util.List;
import java.util.ArrayList;

public abstract class Personagem {

	protected String codinome, nome;
	List<SuperPoder> poderes;
	
	public Personagem(String codinome, String nome) {
		this.codinome = codinome;
		this.nome = nome;
		poderes = new ArrayList<SuperPoder>();
	}
	
	public abstract void adicionaPoder(String nome, Integer categoria);
	public abstract Double getForcaTotal();
	
	public String getCodinome() {
		return codinome;
	}
	public String getNome() {
		return nome;
	}
	public List<SuperPoder> getPoderes() {
		return poderes;
	}
	
	@Override
	public String toString() {
		return String.format("\nCodinome: " + codinome + "\nNome do personagem: " + nome + "\nPoderes: " + poderes);
	}
}

// Uma classe abstrata "Personagem", que deve conter:
//
//    I. Atributos:
//
//codinome - String - representa o codinome (como ele costuma ser reconhecido) do personagem.
//nome - String - representa o nome verdadeiro, caso o personagem tenha um codinome.
//poderes - List - representa a lista de poderes que o personagem possuí.
//    II. Métodos:
//


//adicionaPoder - void - recebe dois argumentos, "String nome" 
//e "Integer categoria", cria e adiciona um super poder à lista de poderes do personagem.


//getForcaTotal - Double - método abstrato.
//Getters - para recuperar as informações do objeto.
//toString() - String - retorna uma string para exibir as informações do objeto.