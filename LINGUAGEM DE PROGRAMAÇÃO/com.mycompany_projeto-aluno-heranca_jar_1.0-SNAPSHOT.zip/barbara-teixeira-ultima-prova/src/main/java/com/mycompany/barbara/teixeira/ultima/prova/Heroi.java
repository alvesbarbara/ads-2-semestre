package com.mycompany.barbara.teixeira.ultima.prova;

import java.util.List;

public class Heroi extends Personagem {
      Heroi(String ninja_cabeça_oca, String uzumaki_naruto) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void adicionaPoder(String nome, Integer categoria) {
       
    }

    @Override
    public Double getForcaTotal() {
        Double calculo = 0.0;
        if(!poder.isEmpty()){
      for(Personagem poderes: poder){
        calculo += poderes.categoria;
      }
        }
        return calculo * 1.5;
    }
}
   
      
        
    
       


//C) Uma classe "Heroi" herdeira de "Personagem", que deve conter:
//
//    I. Métodos:
//
//getForcaTotal - Double - esse método deve percorrer a lista de poderes 
//do heroi e retornar o valor total dos poderes (baseado na categoria), adicionando 5% ao valor total.