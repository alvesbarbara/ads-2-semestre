
package com.mycompany.barbara.teixeira.ultima.prova;

    public class SuperPoder {
	protected String nome;
	protected Integer categoria;
	
	public SuperPoder(String nome, Integer categoria) {
		this.nome = nome;
		this.categoria = categoria;
	}
	
	public String getNome() {
		return nome;
	}
	public Integer getCategoria() {
		return categoria;
	}
	
	@Override
	public String toString() {
		return String.format("Nome do poder: " + nome + "\nCategoria: " + categoria);
	}
}


//A) Uma classe "SuperPoder", que deve conter:
//
//    I. Atributos:
//
//nome - String - representa o nome do super poder.
//categoria - Integer - representa a força do super poder.
//    II. Métodos:
//
//Getters - para recuperar as informações do objeto.
//toString() - String - retorna uma string para exibir as informações do objeto.