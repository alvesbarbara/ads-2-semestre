
package com.mycompany.barbara.teixeira.ultima.prova;

public class Vilao extends Personagem{
	public Vilao(String codinome, String nome) {
		super(codinome, nome);
	}

	@Override
	public void adicionaPoder(String nome, Integer categoria) {
		SuperPoder poder = new SuperPoder(nome, categoria);
		poderes.add(poder);
	}

	@Override
	public Double getForcaTotal() {
		Double calculo = 0.;
		for(SuperPoder poder : poderes) {
			calculo += poder.getCategoria();
		}
		return calculo;
	}
}
