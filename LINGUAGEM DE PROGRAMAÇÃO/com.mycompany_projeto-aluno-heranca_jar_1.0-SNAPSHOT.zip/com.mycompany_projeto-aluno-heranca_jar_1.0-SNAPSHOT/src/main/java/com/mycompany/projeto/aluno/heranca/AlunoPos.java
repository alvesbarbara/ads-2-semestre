package com.mycompany.projeto.aluno.heranca;

public class AlunoPos extends Aluno {
  protected   Double notaMonografia;
 
  public AlunoPos(Integer ra, String nome, Double notaContinuada, Double notaSemestral, Double notaMonografia){
  super (ra, nome, notaContinuada, notaSemestral);
  
  this.notaMonografia = notaMonografia;
  }
  
 @Override
 public Double calcularMedia(){
 Double mediaAlunoPos = (notaContinuada + notaSemestral + notaMonografia)/3;
 return mediaAlunoPos;
 }

    public Double getNotaMonografia() {
        return notaMonografia;
    }

@Override
    public String toString() {
        System.out.println("---   Aluno Pós  ---");
        return String.format("RA: " + this.ra + "\nNome: " + this.nome + "\nNota Continuada: " 
        + this.notaContinuada + "\nNota Semestral: " + this.notaSemestral + "\nNota Monográfica: "
        + this.notaMonografia + "\nMédia: %.2f", this.calcularMedia());
    }
    
}
