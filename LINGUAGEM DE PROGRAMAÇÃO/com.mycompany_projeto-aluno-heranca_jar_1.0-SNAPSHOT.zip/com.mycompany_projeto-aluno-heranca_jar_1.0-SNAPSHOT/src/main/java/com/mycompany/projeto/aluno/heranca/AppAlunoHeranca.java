
package com.mycompany.projeto.aluno.heranca;


public class AppAlunoHeranca {
   
  public static void main(String[] args) {
      
       Aluno aluno = new Aluno(119211, "Henrique", 8.0, 9.5);
       
       AlunoPos alunoPos = new AlunoPos (123456, "Enzo", 10.0, 9.9, 10.0);
        
        System.out.println("Aluno " + aluno.getNome() + "tem média: " + aluno.calcularMedia());  
       

         System.out.println("Aluno " + alunoPos.getNome() + "tem média: " + alunoPos.calcularMedia());  
        
    }
    
}
