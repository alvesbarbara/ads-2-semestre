package com.mycompany.barbara.teixeira.ultima.prova;

public class App {
    
	public static void main(String[] args) {
		Heroi ninja1 = new Heroi("ninja cabeça oca", "uzumaki naruto");
		Heroi ninja2 = new Heroi(" Sannin Lendários", "Jiraya");
		Vilao ninjav1 = new Vilao("Ninja renegado", "uchiha itachi");
		Vilao ninjav2 = new Vilao("Cobra Branca", "Orochimaru");

		ninja1.adicionaPoder("Clone das sombras", 7);
		ninja1.adicionaPoder("Razengan", 10);

		ninja2.adicionaPoder("razengan", 10);
		ninja2.adicionaPoder("Tecnica de invocação", 8);

		ninjav1.adicionaPoder("Genjutsu", 7);
		ninjav1.adicionaPoder("Bola de fogo", 9);

		ninjav2.adicionaPoder("Edo-Tensei", 3);
		ninjav2.adicionaPoder("Encontro de cobras", 6);
                
                

                System.out.println();
		System.out.println(" Vilõe ");
		System.out.println(ninjav1);
		System.out.println(ninjav2 + "\n");
                
                
		System.out.println("Heróis");
		System.out.println(ninja1);
		System.out.println(ninja2);

	
		

		System.out.println("Confronto entre: " + ninja1.codinome + " vs " + ninjav1.codinome);
		Confronto.lutar(ninja1, ninjav1);

		System.out.println();
		System.out.println("Confronto entre: " + ninja2.codinome + " vs " + ninjav2.codinome);
		Confronto.lutar(ninja2, ninjav2);
	}
}


//F) Uma classe "App", que deve ser executável e conter:
//
//    I. Instâncias de Heroi (mínimo 2) com poderes cadastrados.
//
//    II. Instâncias de Vilão (mínimo 2) com poderes cadastrados.
//
//    III. Crie o combate entre os heróis e os vilões invocando o método 
//lutar da classe criada no passo "E" e apresente o vencedor, 
//
//       exemplo: 