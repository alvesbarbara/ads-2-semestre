
package com.mycompany.barbara.teixeira.ultima.prova;

public class Confronto {
	public static void lutar(Heroi heroi, Vilao vilao) {
		if(heroi.getForcaTotal() > vilao.getForcaTotal()) {
			System.out.println("E mais uma vez o dia foi salvo por, " + heroi.getCodinome());
		}
		else if(vilao.getForcaTotal() < heroi.getForcaTotal()) {
			System.out.println("O mal prevaleceu, mas não por muito tempo, " + vilao.getCodinome());
		}else {
			System.out.println("Empate entre: " + heroi.getCodinome() + vilao.getCodinome());
		}
	}
}


//E) Uma classe "Confronto", que deve conter:
//
//    I. Métodos:
//
//lutar - void - método estático que recebe dois argumentos, 
//"Heroi heroi" e "Vilao vilao", esse método deve comparar o valor total dos poderes dos personagens recebidos 
//e exibir no console um texto com o nome do vencedor do combate, inclusive, deve tratar caso ocorra um empate.