
package com.mycompany.barbara.teixeira.ultima.prova;

import java.util.List;


public class Vilao extends Personagem {

    public Vilao(String codinome, String nome, Integer categoria, List<Personagem> poder) {
        super(codinome, nome, categoria, poder);
    }

    Vilao(String ninja_renegado, String uchiha_itachi) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }


    
  @Override
    public Double getForcaTotal() {
        Double forcaTotal = 0.;
        for(Personagem poder : poder) {
            forcaTotal += poder.categoria;
        }
        return forcaTotal;
    }

    @Override
    public void adicionaPoder(String nome, Integer categoria) {
        
    }

 

 
    
    
    
    }
//D) Uma classe "Vilao" herdeira de "Personagem", que deve conter:
//
//    I. Métodos:
//
//getForcaTotal - Double - esse método deve percorrer a lista de
//poderes do vilão e retornar o valor total dos poderes (baseado na categoria).