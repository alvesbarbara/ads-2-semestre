package com.mycompany.telegram;

public class AppTelegram {
    public static void main(String[] args) {
        
    }
    
}
