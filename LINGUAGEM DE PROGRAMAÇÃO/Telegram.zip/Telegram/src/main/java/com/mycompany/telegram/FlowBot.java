
package com.mycompany.telegram;

public class FlowBot {
    
}
