
package com.mycompany.projeto.aluno.heranca;
public class Aluno {
    protected Integer ra;
    protected String nome;
    protected Double notaContinuada;
    protected Double notaSemestral;
    


public Aluno(Integer ra, String nome, Double notaContinuada, Double notaSemestral){
this.ra = ra;
this.nome = nome;        
this.notaContinuada= notaContinuada;
this.notaSemestral = notaSemestral;

}

public Double calcularMedia(){
    Double calcular = (notaContinuada * 0.4) + (notaSemestral * 0.6);
        return calcular;
}

    public Integer getRa() {
        return ra;
    }

    public String getNome() {
        return nome;
    }

    public Double getNotaContinuada() {
        return notaContinuada;
    }

    public Double getNotaSemestral() {
        return notaSemestral;
    }




@Override
    public String toString() {
        System.out.println("   Aluno Pós  ");
        return String.format("RA: " + this.ra + "\nNome: " + this.nome + "\nNota Continuada: " 
        + this.notaContinuada + "\nNota Semestral: " + this.notaSemestral + "\nMédia: %.2f", this.calcularMedia());
    }

}