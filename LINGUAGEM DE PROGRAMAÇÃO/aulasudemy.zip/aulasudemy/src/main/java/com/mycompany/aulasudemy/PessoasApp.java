
package com.mycompany.aulasudemy; //convenção que pacotes sempre são declarados com tudo em letra minuscula

public class PessoasApp {// App convenção de tudo que for Application
    
    public static void main(String[] args) { // main indica que a classe é executavel 
        
       Pessoas pessoa1 = new Pessoas(1, "Bárbara"); //pessoa1 ée um OBJETO é pertence a classe Pessoas 
       Pessoas pessoa2 = new Pessoas(2, "Luiza");
        
    }
}
