
package com.mycompany.aulasudemy;

public class Pessoas {
    Integer codigo;
    String nome;
            
public Pessoas (int codigo, String nome){// METODO CONSTRUTOR
    this.codigo = codigo;
    this.nome = nome;
    
}
}
    

