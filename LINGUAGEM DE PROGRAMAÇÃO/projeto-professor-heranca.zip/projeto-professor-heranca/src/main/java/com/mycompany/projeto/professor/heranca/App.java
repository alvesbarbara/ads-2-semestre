
package com.mycompany.projeto.professor.heranca;

/**
 *
 * @author re92260z
 */
public class App {
   
    public static void main(String[] args) {

        Professor professor = new Professor("Kakashi",300, 4, 50.0);
        Cordenador cordernador = new Cordenador("Naruto","Jutso Clone Das Sombras",7, 7, 2, 30.0, 5.0);

        
        System.out.println(professor + "\n");
       
        System.out.println(cordernador);
     
    }
}

