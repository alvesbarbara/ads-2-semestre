
package com.mycompany.barbara.teixeira.c3;

public class DentistaClinico extends Dentista{
protected Integer consultas;    
protected Double valorConsulta;

    public DentistaClinico(Integer consultas, Double valorConsulta, Integer codigo, String nome) {
        super(codigo, nome);
        this.consultas = consultas;
        this.valorConsulta = valorConsulta;
    }



    @Override
    public Double calculaSalario() {
        return consultas * valorConsulta;
       
    }

    @Override
    public String toString() {
        return "DentistaClinico{" + "consultas=" + consultas + ", valorConsulta=" + valorConsulta + '}';
    }

    public Integer getConsultas() {
        return consultas;
    }

    public Double getValorConsulta() {
        return valorConsulta;
    }



    
}


//A) Atributos:
//
//consultas – Integer – representa o númndsero de consultas realizadas.
//valorConsulta – Double – representa valor da consulta.
//B) Métodos:
//
//calculaSalario – retorna Double – quantidade de consultas vezes  valor da consulta.
//toString – retorna String – retorna texto com os valores do objeto inclusive seus ganhos.