
package com.mycompany.barbara.teixeira.c3;

public class AppClinica {
    public static void main(String[] args) {
        DentistaClinico d = new DentistaClinico(14, 200.0, 1010, "Caiego");
        DentistaClinico d2 = new DentistaClinico(16, 400.0, 1011, "Diaio");
        DentistaCirurgiao c = new DentistaCirurgiao (100, 2000, "Bruce");
        DentistaCirurgiao c2 = new DentistaCirurgiao (101, 2001, "Robbin");
        
        System.out.println(d);
        System.out.println(d2);
        System.out.println(c);
        System.out.println(c2);
        
        ClinicaOdontologica co = new ClinicaOdontologica("Arkham");
        
        co.contrataDentista(d);
        co.contrataDentista(d2);
        
        co.exibeClinico();
        
        co.contrataDentista(c);
        co.contrataDentista(c2);
        
        co.exibeCirurgião();
        co.exibeFolhaDePagamentos();
    }
}


//A) Dentro do main, crie objetos dos tipos DentistaClinico(mínimo dois), DentistaCirurgiao (mínimo dois) e Clinica.

//B) Utilize os métodos contidos dentro do objeto clínica para contratar e exibir as informações(passo 4-b).