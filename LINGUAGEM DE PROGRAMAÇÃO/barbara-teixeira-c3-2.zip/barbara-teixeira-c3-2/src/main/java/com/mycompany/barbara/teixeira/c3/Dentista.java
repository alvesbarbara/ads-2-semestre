
package com.mycompany.barbara.teixeira.c3;

public  abstract class  Dentista {
    protected Integer codigo; //representa o código do dentista(CRO).
    protected String nome; // representa o nome do dentista.

    public Dentista(Integer codigo, String nome) {
        this.codigo = codigo;
        this.nome = nome;
    }
//Métodos

    public abstract Double calculaSalario();
    
    @Override
    public String toString() {
        return "Dentista{" + "codigo=" + codigo + ", nome=" + nome + '}';
    }

    public Integer getCodigo() {
        return codigo;
    }

    public String getNome() {
        return nome;
    }
    
    
}



//B) Métodos:
//
//calculaSalario – retorna Double - método abstrato.
//toString – retorna String – retorna um texto com os dados do objeto.
