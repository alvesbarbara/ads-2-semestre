package com.mycompany.barbara.teixeira.c3;

import java.util.List;
import java.util.ArrayList;

public class ClinicaOdontologica {
    protected String nome;
    private List<Dentista> dentistas;

    public ClinicaOdontologica(String nome) {
        this.nome = nome;
        dentistas = new ArrayList<>();
    }
    
    
      
public void contrataDentista(Dentista dentista){
dentistas.add(dentista);
}  

public void exibeClinico(){
   if(!dentistas.isEmpty()){
      for(Dentista dentista : dentistas){
         if(dentista instanceof DentistaClinico){
            System.out.println(dentista);
         }
      }
   }
}
 
public void exibeCirurgião(){
   if(!dentistas.isEmpty()){
      for(Dentista dentista : dentistas){
         if(dentista instanceof DentistaCirurgiao){
            System.out.println(dentista);
         }
      }
   }
}

public void exibeFolhaDePagamentos(){
Double totalPagamento= 0.0;
if(!dentistas.isEmpty()){
for(Dentista dentista: dentistas){
    System.out.println(nome);
    System.out.println(dentista.getNome());
    System.out.println(dentista.calculaSalario());
    totalPagamento += dentista.calculaSalario();
    
}
    System.out.println(String.format("Valor a ser disponibilizado %.2f", totalPagamento));
}

}
}

//4. Uma classe ClinicaOdontologica:
//
//A) Atributos:
//
//nome – String - representa o nome do hospital.
//dentistas – List – representa os dentistas residentes da clínica.
//B) Métodos:
//
//contrataDentista – void (Dentista dentista) – recebe e cadastra o dentista na clínica.
//exibeClinicos  - void – exibe somente os dentistas clínicos residentes.
//exibeCirurgioes – void exibe somente os dentistas cirurgiões residentes.
//ExibeFolhaDePagamento – void – exibe os nomes dos dentistas residentes 
//juntamente com o seu salário, ao final, mostra o valor total que deve ser
//disponibilizado para realizar os pagamentos.
