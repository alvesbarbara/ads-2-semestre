
package com.mycompany.barbara.teixeira.c3;

public class DentistaCirurgiao extends Dentista{
    protected Integer cirurgias;
    protected Double valorCirurgia;
    
    public DentistaCirurgiao(Integer cirurgias, Integer codigo, String nome) {
        super(codigo, nome);
        this.cirurgias = cirurgias;
        this.valorCirurgia = valorCirurgia;
    }

    @Override
    public Double calculaSalario() {
        return cirurgias * valorCirurgia;
    }

    @Override
    public String toString() {
        return "DentistaCirurgi\u00e3o{" + "cirurgias=" + cirurgias + ", valorCirurgia=" + valorCirurgia + calculaSalario() + '}';
    }

    public Integer getCirurgias() {
        return cirurgias;
    }

    public Double getValorCirurgia() {
        return valorCirurgia;
    }

    public Integer getCodigo() {
        return codigo;
    }

    public String getNome() {
        return nome;
    }
    
    
}



//3. Uma classe DentistaCirugiao :
//
//A) Atributos:
//
//cirurgias- Integer – representa a quantidade de cirurgias realizadas.
//valorCirurgia - Double – representa o valor de cada cirurgia.
//B) Métodos:
//
//calculaSalario – retorna Double – quantidade de cirurgias vezes valor da cirurgia.
//toString – retorna String – retorna texto com os valores do objeto inclusive seus ganhos.