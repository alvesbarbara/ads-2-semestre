
import java.util.Scanner;
public class Continuada1 {
    public static void main(String[] args) {
        
         Scanner leitor = new Scanner(System.in);
         
        
       
        System.out.println("Qual seu primeiro nome");
         String nome = leitor.nextLine();
                
      
    double  mes, acumulado;
    
    acumulado = 0;
    for( int i = 0; i <12; i++ ){
    System.out.println( "Qual valor depoisitado no mÊs " + (i+1));
     mes = leitor.nextDouble();
     
     acumulado = acumulado + mes;
     
     
}
 
    System.out.println("Ao final de 12 meses " + nome +  " guardou R$" + acumulado);
}
    
}

//b) Pergunte ao usuário seu primeiro nome
//
//c) Pergunte 12 vezes o valor do depósito realizado com uma frase como esta: "Valor depositado no Xº mês:", onde X vai de 1 a 12.
//
//d) Ao receber o valor de cada depósito, apenas aceite valores de 2,00; 5,00; 10,00; 20,00; 50,00; 100,00, afinal são as únicas cédulas que temos.
//Ignore qualquer outro valor, considerando que foi depositado nada.
//
//e) Após os 12 depósitos, exiba uma frase com esta: "Ao final de 12 meses, X guardou R$Y".
//Onde X é o nome recebido no item b) e Y é a soma de todos os depósitos válidos.
//Use a técnica da interpolação e arredonde os valores monetários exibidos para 2 casas decimais.